package com.englishpilot

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class Capped(c: Context, private val maxH: Int) : FrameLayout(c) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

class PilotService : AccessibilityService() {
    private val INK = Color.parseColor("#12262B")
    private val MUTE = Color.parseColor("#5D7378")
    private val PRI = Color.parseColor("#12565F")
    private val TINT = Color.parseColor("#E3F0EE")
    private val RED = Color.parseColor("#B3392F")
    private val GREEN = Color.parseColor("#1D7A4D")
    private val AMBER = Color.parseColor("#C98A0B")

    private lateinit var wm: WindowManager
    private lateinit var st: Store
    private val h = Handler(Looper.getMainLooper())
    private var bubble: TextView? = null
    private var panel: View? = null
    private var node: AccessibilityNodeInfo? = null
    private var lastChecked = ""
    private var result: Fix? = null
    private var busy = false
    private val cache = HashMap<String, Fix>()
    private val autoRun = Runnable { autoCheck() }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        st = Store(this)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        hideAll()
        super.onDestroy()
    }

    // ---------- events ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!::wm.isInitialized) return
        val pkg = e.packageName?.toString() ?: ""
        if (pkg == packageName) return
        when (e.eventType) {
            AccessibilityEvent.TYPE_VIEW_FOCUSED, AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                val src = e.source ?: return
                if (src.isEditable && !src.isPassword) {
                    node = src
                    showBubble()
                    if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED && st.auto) {
                        h.removeCallbacks(autoRun)
                        h.postDelayed(autoRun, 2200)
                    }
                } else if (e.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED) {
                    hideAll()
                }
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val low = pkg.lowercase()
                val isKeyboard = low.contains("inputmethod") || low.contains("keyboard") || low.contains("honeyboard") ||
                    low.contains("swiftkey") || low.contains(".ime")
                if (!isKeyboard) {
                    val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                    if (f != null && f.isEditable && !f.isPassword) {
                        node = f
                        showBubble()
                    } else hideAll()
                }
            }
        }
    }

    private fun curText(): String {
        val n = node ?: return ""
        n.refresh()
        if (n.isShowingHintText) return ""
        return n.text?.toString() ?: ""
    }

    private fun setField(s: String): Boolean {
        val n = node ?: return false
        n.refresh()
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- checking ----------
    private fun autoCheck() {
        val t = curText()
        if (t.length < 15 || t == lastChecked || panel != null) return
        run(t, false)
    }

    private fun run(t: String, manual: Boolean) {
        val c = cache[t]
        if (c != null) {
            result = c
            lastChecked = t
            badge(c)
            if (manual) showPanel(c)
            return
        }
        if (busy) return
        busy = true
        setBubble("…", PRI)
        Thread {
            val r = runCatching { Coach.fix(st, t) }
            h.post {
                busy = false
                r.onSuccess {
                    if (cache.size > 30) cache.clear()
                    cache[t] = it
                    result = it
                    lastChecked = t
                    badge(it)
                    if (manual) showPanel(it)
                }.onFailure {
                    setBubble("!", RED)
                    if (manual) showSimple("Could not check", errText(it), false) {}
                }
            }
        }.start()
    }

    private fun onBubbleTap() {
        val t = curText()
        if (t.isBlank()) {
            toast("Type something first.")
            return
        }
        val r = result
        if (r != null && lastChecked == t) showPanel(r) else run(t, true)
    }

    private fun badge(f: Fix) {
        if (f.changes.isEmpty()) setBubble("✓", GREEN)
        else setBubble(f.changes.size.toString(), if (f.changes.size > 3) RED else AMBER)
    }

    // ---------- bubble ----------
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun round(c: Int, r: Int, oval: Boolean = false): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(c)
        if (oval) g.shape = GradientDrawable.OVAL else g.cornerRadius = r.toFloat()
        return g
    }

    private fun setBubble(t: String, color: Int) {
        val b = bubble ?: return
        b.text = t
        b.background = round(color, 0, true)
    }

    private fun showBubble() {
        val old = bubble
        if (old != null) {
            old.visibility = View.VISIBLE
            return
        }
        val b = TextView(this)
        b.text = "E"
        b.setTextColor(Color.WHITE)
        b.textSize = 18f
        b.gravity = Gravity.CENTER
        b.setTypeface(null, Typeface.BOLD)
        b.background = round(PRI, 0, true)
        b.elevation = 8f
        val sz = dp(46)
        val lp = WindowManager.LayoutParams(
            sz, sz, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = resources.displayMetrics.heightPixels / 3
        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0
        var moved = false
        b.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    dx = ev.rawX; dy = ev.rawY; sx = lp.x; sy = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (ev.rawX - dx).toInt()
                    val my = (ev.rawY - dy).toInt()
                    if (abs(mx) > 12 || abs(my) > 12) moved = true
                    if (moved) {
                        lp.x = sx + mx
                        lp.y = sy + my
                        wm.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onBubbleTap()
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(b, lp)
            bubble = b
        } catch (e: Exception) {
        }
    }

    private fun hideAll() {
        h.removeCallbacks(autoRun)
        closePanel()
        bubble?.visibility = View.GONE
        node = null
        result = null
        lastChecked = ""
    }

    // ---------- panel ----------
    private fun closePanel() {
        val p = panel
        if (p != null) {
            try { wm.removeView(p) } catch (e: Exception) {}
            panel = null
        }
    }

    private fun tx(t: CharSequence, size: Float = 15f, bold: Boolean = false, color: Int = INK): TextView {
        val x = TextView(this)
        x.text = t
        x.textSize = size
        x.setTextColor(color)
        if (bold) x.setTypeface(null, Typeface.BOLD)
        x.setPadding(0, dp(4), 0, dp(4))
        return x
    }

    private fun pill(t: String, filled: Boolean, f: () -> Unit): TextView {
        val x = tx(t, 15f, true, if (filled) Color.WHITE else PRI)
        x.gravity = Gravity.CENTER
        x.setPadding(dp(16), dp(10), dp(16), dp(10))
        x.background = round(if (filled) PRI else TINT, dp(18))
        x.setOnClickListener { f() }
        return x
    }

    private fun lpw(): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(-2, -2)
        l.rightMargin = dp(8)
        return l
    }

    private fun mount(card: LinearLayout) {
        closePanel()
        val wrap = Capped(this, (resources.displayMetrics.heightPixels * 0.72).toInt())
        val sc = ScrollView(this)
        sc.addView(card)
        wrap.addView(sc)
        wrap.background = round(Color.WHITE, dp(24))
        wrap.elevation = 16f
        val lp = WindowManager.LayoutParams(
            -1, -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.BOTTOM
        try {
            wm.addView(wrap, lp)
            panel = wrap
        } catch (e: Exception) {
        }
    }

    private fun newCard(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(18), dp(14), dp(18), dp(18))
        return c
    }

    private fun header(card: LinearLayout, title: String, right: String) {
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tx(title, 18f, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (right.isNotBlank()) head.addView(tx(right, 15f, true, PRI))
        val x = tx("   ✕", 20f, true, MUTE)
        x.setOnClickListener { closePanel() }
        head.addView(x)
        card.addView(head)
    }

    private fun showSimple(title: String, body: String, canUse: Boolean, onUse: () -> Unit) {
        val card = newCard()
        header(card, title, "")
        card.addView(tx(body, 17f))
        val row = LinearLayout(this)
        row.setPadding(0, dp(10), 0, 0)
        if (canUse) row.addView(pill("Use this", true) { onUse() }, lpw())
        row.addView(pill("Close", false) { closePanel() }, lpw())
        card.addView(row)
        mount(card)
    }

    private fun showPanel(f: Fix) {
        val card = newCard()
        header(card, "EnglishPilot", if (f.score > 0) "Score ${f.score}" else "")
        if (f.tone.isNotBlank()) card.addView(tx("Tone: ${f.tone}", 14f, false, MUTE))
        card.addView(tx(if (f.changes.isEmpty()) "No mistakes found. Nice writing." else "${f.changes.size} suggestion(s)", 15f, true, PRI))
        card.addView(tx(f.corrected, 17f))
        val row = LinearLayout(this)
        row.setPadding(0, dp(8), 0, dp(4))
        if (f.changes.isNotEmpty()) row.addView(pill("Replace all", true) {
            if (setField(f.corrected)) {
                lastChecked = f.corrected
                closePanel()
                setBubble("✓", GREEN)
            } else toast("This app does not allow replacing. Use Copy.")
        }, lpw())
        row.addView(pill("Copy", false) {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("fixed", f.corrected))
            toast("Copied")
        }, lpw())
        card.addView(row)

        card.addView(tx("Rewrite as", 14f, true, MUTE))
        val chips = LinearLayout(this)
        for (m in listOf("Formal", "Friendly", "Confident", "Polite", "Shorter", "Simpler")) {
            val c = pill(m, false) { rewrite(m) }
            chips.addView(c, lpw())
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips)
        card.addView(hs)

        for (c in f.changes) {
            val s = SpannableString("${c.wrong}  →  ${c.right}")
            val w = c.wrong.length
            s.setSpan(StrikethroughSpan(), 0, w, 0)
            s.setSpan(ForegroundColorSpan(RED), 0, w, 0)
            val a = w + 5
            if (a < s.length) {
                s.setSpan(ForegroundColorSpan(GREEN), a, s.length, 0)
                s.setSpan(StyleSpan(Typeface.BOLD), a, s.length, 0)
            }
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.setPadding(dp(12), dp(10), dp(12), dp(10))
            item.background = round(TINT, dp(14))
            item.addView(tx(s, 16f))
            item.addView(tx("${c.type.ifBlank { "Correctness" }} · ${c.cat}", 13f, false, MUTE))
            item.addView(tx(c.why, 15f))
            val acc = pill("Accept", true) {}
            acc.setOnClickListener {
                val t = curText()
                if (c.wrong.isNotEmpty() && t.contains(c.wrong)) {
                    val n = t.replaceFirst(c.wrong, c.right)
                    if (setField(n)) {
                        lastChecked = n
                        acc.text = "Done ✓"
                        acc.setOnClickListener(null)
                    }
                } else toast("The text changed. Tap the E button to check again.")
            }
            item.addView(acc, lpw())
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(10)
            card.addView(item, lp)
        }
        if (f.tip.isNotBlank()) {
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(12)
            card.addView(tx("Remember: ${f.tip}", 15f, true, PRI), lp)
        }
        mount(card)
    }

    private fun rewrite(mode: String) {
        val t = curText()
        if (t.isBlank()) return
        closePanel()
        setBubble("…", PRI)
        Thread {
            val r = runCatching { Coach.rewrite(st, t, mode) }
            h.post {
                setBubble("E", PRI)
                r.onSuccess { out ->
                    showSimple("Rewritten: $mode", out, true) {
                        if (setField(out)) lastChecked = out
                        closePanel()
                    }
                }.onFailure { showSimple("Could not rewrite", errText(it), false) {} }
            }
        }.start()
    }
}
