package com.englishpilot

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray

class MainActivity : Activity() {
    lateinit var st: Store
    lateinit var body: FrameLayout
    var shared: String? = null
    val PRI = Color.parseColor("#12565F")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Store(this)
        shared = intent?.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.fitsSystemWindows = true
        body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this)
        val tabs = listOf<Pair<String, () -> Unit>>(
            "Fix" to { fixTab() }, "Practice" to { practiceTab() },
            "Progress" to { progressTab() }, "Setup" to { setupTab() })
        for ((n, f) in tabs) nav.addView(btn(n) { f() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(nav)
        setContentView(root)
        if (st.key.isBlank() && st.base.contains("groq.com")) setupTab() else fixTab()
    }

    fun svcOn(): Boolean {
        val e = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return e.contains(packageName)
    }
    fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    fun tv(t: String, size: Float = 16f, bold: Boolean = false): TextView {
        val x = TextView(this)
        x.text = t
        x.textSize = size
        if (bold) x.setTypeface(null, Typeface.BOLD)
        x.setPadding(0, dp(6), 0, dp(6))
        return x
    }
    fun btn(t: String, f: () -> Unit): Button {
        val x = Button(this)
        x.text = t
        x.isAllCaps = false
        x.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.setColor(PRI)
        g.cornerRadius = dp(12).toFloat()
        x.background = g
        x.setOnClickListener { f() }
        return x
    }
    fun col(): LinearLayout {
        val x = LinearLayout(this)
        x.orientation = LinearLayout.VERTICAL
        x.setPadding(dp(16), dp(12), dp(16), dp(12))
        return x
    }
    fun page(v: View) {
        body.removeAllViews()
        val s = ScrollView(this)
        s.addView(v)
        body.addView(s)
    }
    fun <T> bg(work: () -> T, done: (Result<T>) -> Unit) {
        Thread {
            val r = runCatching(work)
            runOnUiThread { done(r) }
        }.start()
    }
    fun norm(s: String) = s.lowercase().replace(Regex("\\s+"), " ").trim()
    fun norm2(s: String) = s.lowercase().replace(Regex("[^\\w\\s']"), "").replace(Regex("\\s+"), " ").trim()
    fun copy(s: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("fixed", s))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }
    fun red(t: TextView): TextView { t.setTextColor(Color.parseColor("#B3392F")); return t }

    // ---------- Fix ----------
    fun fixTab() {
        val v = col()
        v.addView(tv("Fix my English", 22f, true))
        val inp = EditText(this)
        inp.hint = "Type or paste your message"
        inp.minLines = 5
        inp.gravity = Gravity.TOP
        inp.setText(shared ?: "")
        val tryCb = CheckBox(this)
        tryCb.text = "Let me try fixing it first"
        val out = LinearLayout(this)
        out.orientation = LinearLayout.VERTICAL
        val msg = red(tv("", 14f))
        val go = Button(this)
        go.text = "Fix my English"
        go.isAllCaps = false
        val row = LinearLayout(this)
        row.addView(btn("Paste") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            inp.setText(cm.primaryClip?.getItemAt(0)?.coerceToText(this) ?: "")
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("Clear") { inp.setText(""); out.removeAllViews() }, LinearLayout.LayoutParams(0, -2, 1f))
        go.setOnClickListener {
            val t = inp.text.toString().trim()
            if (t.isNotEmpty()) {
                msg.text = ""
                out.removeAllViews()
                go.isEnabled = false
                go.text = "Checking..."
                bg({ Coach.fix(st, t) }) { res ->
                    go.isEnabled = true
                    go.text = "Fix my English"
                    res.onSuccess { showFix(out, t, it, tryCb.isChecked) }.onFailure { msg.text = errText(it) }
                }
            }
        }
        for (x in listOf<View>(inp, row, tryCb, go, msg, out)) v.addView(x)
        page(v)
    }

    fun showFix(out: LinearLayout, t: String, f: Fix, tryFirst: Boolean) {
        val answer = LinearLayout(this)
        answer.orientation = LinearLayout.VERTICAL
        answer.addView(tv("Corrected", 18f, true))
        answer.addView(tv(f.corrected, 17f))
        answer.addView(btn("Copy") { copy(f.corrected) })
        answer.addView(tv(if (f.changes.isEmpty()) "No mistakes found" else "${f.changes.size} change(s)", 18f, true))
        for (c in f.changes) answer.addView(tv("${c.wrong}  →  ${c.right}\n${c.cat}: ${c.why}", 15f))
        if (f.tip.isNotBlank()) answer.addView(tv("Remember: ${f.tip}", 15f, true))
        if (tryFirst && f.changes.isNotEmpty()) {
            out.addView(tv("Your turn", 18f, true))
            out.addView(tv("Rewrite your text with every fix you can find.", 15f))
            val mine = EditText(this)
            mine.setText(t)
            out.addView(mine)
            val cmp = tv("", 15f)
            out.addView(btn("Check my fix") {
                cmp.text = if (norm(mine.text.toString()) == norm(f.corrected)) "Perfect match. You fixed it yourself."
                else "Close, but not identical. Compare with the answer below."
                if (answer.parent == null) out.addView(answer)
            })
            out.addView(cmp)
        } else out.addView(answer)
    }

    // ---------- Practice ----------
    fun practiceTab() {
        val v = col()
        v.addView(tv("Practice", 22f, true))
        v.addView(tv("Sentences built from your own most common mistakes.", 15f))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val msg = red(tv("", 14f))
        val go = Button(this)
        go.text = "Make my practice"
        go.isAllCaps = false
        go.setOnClickListener {
            go.isEnabled = false
            list.removeAllViews()
            msg.text = ""
            bg({ Coach.practice(st) }) { res ->
                go.isEnabled = true
                res.onSuccess { items ->
                    for ((w, a, rule) in items) {
                        list.addView(tv("Fix this sentence:\n$w", 17f))
                        val e = EditText(this)
                        list.addView(e)
                        val fb = tv("", 15f)
                        list.addView(btn("Check") {
                            val ok = norm2(e.text.toString()) == norm2(a)
                            fb.text = (if (ok) "Correct.\n" else "Not yet.\n") + "Answer: $a\n$rule"
                        })
                        list.addView(fb)
                    }
                }.onFailure { msg.text = errText(it) }
            }
        }
        for (x in listOf<View>(go, msg, list)) v.addView(x)
        page(v)
    }

    // ---------- Progress ----------
    fun progressTab() {
        val v = col()
        v.addView(tv("Progress", 22f, true))
        val h = st.hist
        if (h.length() == 0) {
            v.addView(tv("Nothing yet. Fix a message and your progress will appear here.", 16f))
            page(v)
            return
        }
        var w0 = 0; var n0 = 0; var wr = 0; var nr = 0; var wa = 0; var na = 0
        val cnt = HashMap<String, Int>()
        val wk = System.currentTimeMillis() - 604800000L
        for (i in 0 until h.length()) {
            val o = h.getJSONObject(i)
            val w = o.getInt("w"); val n = o.getInt("n")
            wa += w; na += n
            if (o.getLong("t") >= wk) { wr += w; nr += n } else { w0 += w; n0 += n }
            val c = o.getJSONArray("c")
            for (j in 0 until c.length()) cnt[c.getString(j)] = (cnt[c.getString(j)] ?: 0) + 1
        }
        fun rate(n: Int, w: Int): Double = if (w == 0) 0.0 else n * 100.0 / w
        v.addView(tv("Mistakes per 100 words in your own writing", 15f))
        v.addView(tv(String.format("%.1f", rate(na, wa)), 34f, true))
        val trend = if (w0 > 0 && wr > 0)
            String.format("This week %.1f, before %.1f.", rate(nr, wr), rate(n0, w0)) +
                (if (rate(nr, wr) < rate(n0, w0)) " Improving." else " Keep practising.")
        else "Keep writing. The weekly comparison appears after a week of use."
        v.addView(tv(trend, 16f))
        val rows = cnt.entries.sortedByDescending { it.value }
        val mx = rows.firstOrNull()?.value ?: 1
        v.addView(tv("Your most common mistakes", 18f, true))
        for (e in rows) {
            v.addView(tv("${e.key}  (${e.value})", 15f))
            val bar = View(this)
            bar.setBackgroundColor(PRI)
            v.addView(bar, LinearLayout.LayoutParams(dp(maxOf(6, e.value * 240 / mx)), dp(8)))
        }
        v.addView(btn("Clear history") { st.hist = JSONArray(); progressTab() })
        page(v)
    }

    // ---------- Setup ----------
    fun setupTab() {
        val v = col()
        v.addView(tv("Setup", 22f, true))
        fun field(label: String, value: String, pw: Boolean): EditText {
            v.addView(tv(label, 14f))
            val e = EditText(this)
            e.setText(value)
            e.setSingleLine()
            if (pw) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            v.addView(e)
            return e
        }
        val key = field("API key", st.key, true)
        val base = field("Address", st.base, false)
        val model = field("Model", st.model, false)
        val lang = field("Explain mistakes in", st.lang, false)
        val info = tv("", 15f)
        fun save() {
            st.key = key.text.toString().trim()
            st.base = base.text.toString().trim().trimEnd('/')
            st.model = model.text.toString().trim()
            st.lang = lang.text.toString().trim().ifEmpty { "Simple English" }
        }
        v.addView(btn("Use Groq defaults") {
            base.setText("https://api.groq.com/openai/v1")
            model.setText("openai/gpt-oss-120b")
        })
        v.addView(btn("Save") { save(); info.text = "Saved." })
        v.addView(btn("Test connection") {
            save()
            info.text = "Testing..."
            bg({ Api.ask(st, "Reply with JSON only.", "Return {\"ok\":true}") }) { r ->
                info.text = if (r.isSuccess) "Connected." else errText(r.exceptionOrNull())
            }
        })
        v.addView(info)
        v.addView(tv("Local model: enter your server address, for example http://192.168.1.5:11434/v1, and its model name. Your key is stored encrypted on this phone.", 14f))
        v.addView(tv(if (svcOn()) "Floating assistant: ON" else "Floating assistant: OFF", 18f, true))
        v.addView(btn("Turn on floating assistant") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        val auto = CheckBox(this)
        auto.text = "Check automatically when I stop typing"
        auto.isChecked = st.auto
        auto.setOnCheckedChangeListener { _, c -> st.auto = c }
        v.addView(auto)
        v.addView(tv("In Accessibility, open Downloaded apps, tap EnglishPilot and switch it on. If Android says the setting is restricted: Settings, Apps, EnglishPilot, three dots, Allow restricted settings. Then a round E button appears above your keyboard in every app.", 14f))
        v.addView(tv("You can also select text in any app, tap More, then Fix English.", 14f))
        page(v)
    }
}
