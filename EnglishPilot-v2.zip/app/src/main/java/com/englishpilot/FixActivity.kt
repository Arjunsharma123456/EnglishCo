package com.englishpilot

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class FixActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val st = Store(this)
        val text = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString() ?: ""
        val readOnly = intent.getBooleanExtra(Intent.EXTRA_PROCESS_TEXT_READONLY, false)
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.setPadding(48, 32, 48, 32)
        val status = TextView(this)
        status.text = "Fixing your English..."
        status.textSize = 17f
        v.addView(status)
        val sc = ScrollView(this)
        sc.addView(v)
        setContentView(sc)
        val act = this
        Thread {
            val r = runCatching { Coach.fix(st, text) }
            runOnUiThread {
                r.onSuccess { f ->
                    status.text = if (f.changes.isEmpty()) "No mistakes found." else "${f.changes.size} change(s)"
                    val c = TextView(act)
                    c.text = f.corrected
                    c.textSize = 18f
                    c.setPadding(0, 24, 0, 24)
                    c.setTextIsSelectable(true)
                    v.addView(c)
                    for (ch in f.changes) {
                        val t = TextView(act)
                        t.text = "${ch.wrong}  →  ${ch.right}\n${ch.why}"
                        t.textSize = 14f
                        t.setPadding(0, 8, 0, 8)
                        v.addView(t)
                    }
                    if (f.tip.isNotBlank()) {
                        val t = TextView(act)
                        t.text = "Remember: ${f.tip}"
                        t.textSize = 14f
                        t.setPadding(0, 12, 0, 12)
                        v.addView(t)
                    }
                    val row = LinearLayout(act)
                    if (!readOnly) {
                        val rep = Button(act)
                        rep.text = "Replace"
                        rep.isAllCaps = false
                        rep.setOnClickListener {
                            act.setResult(RESULT_OK, Intent().putExtra(Intent.EXTRA_PROCESS_TEXT, f.corrected))
                            act.finish()
                        }
                        row.addView(rep, LinearLayout.LayoutParams(0, -2, 1f))
                    }
                    val cp = Button(act)
                    cp.text = "Copy"
                    cp.isAllCaps = false
                    cp.setOnClickListener {
                        val cm = act.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("fixed", f.corrected))
                        Toast.makeText(act, "Copied", Toast.LENGTH_SHORT).show()
                    }
                    row.addView(cp, LinearLayout.LayoutParams(0, -2, 1f))
                    val cl = Button(act)
                    cl.text = "Close"
                    cl.isAllCaps = false
                    cl.setOnClickListener { act.finish() }
                    row.addView(cl, LinearLayout.LayoutParams(0, -2, 1f))
                    v.addView(row)
                }.onFailure { status.text = errText(it) }
            }
        }.start()
    }
}
