package com.englishpilot

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

class Store(c: Context) {
    private val p: SharedPreferences = c.getSharedPreferences("ep", Context.MODE_PRIVATE)
    private val sec: SharedPreferences = try {
        EncryptedSharedPreferences.create(
            c, "ep_secure",
            MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        c.getSharedPreferences("ep_secure_plain", Context.MODE_PRIVATE)
    }

    var key: String
        get() = sec.getString("key", "") ?: ""
        set(v) { sec.edit().putString("key", v).apply() }
    var base: String
        get() = p.getString("base", "https://api.groq.com/openai/v1") ?: ""
        set(v) { p.edit().putString("base", v).apply() }
    var model: String
        get() = p.getString("model", "openai/gpt-oss-120b") ?: ""
        set(v) { p.edit().putString("model", v).apply() }
    var lang: String
        get() = p.getString("lang", "Simple English") ?: "Simple English"
        set(v) { p.edit().putString("lang", v).apply() }
    var auto: Boolean
        get() = p.getBoolean("auto", true)
        set(v) { p.edit().putBoolean("auto", v).apply() }
    var hist: JSONArray
        get() = try { JSONArray(p.getString("h", "[]")) } catch (e: Exception) { JSONArray() }
        set(v) { p.edit().putString("h", v.toString()).apply() }

    fun addHist(words: Int, cats: List<String>) {
        val old = hist
        val out = JSONArray()
        val start = maxOf(0, old.length() - 299)
        for (i in start until old.length()) out.put(old.get(i))
        out.put(JSONObject().put("t", System.currentTimeMillis()).put("w", words).put("n", cats.size).put("c", JSONArray(cats)))
        hist = out
    }
}
