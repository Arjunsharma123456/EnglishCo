EnglishPilot v2: floating assistant (accessibility service) + app. Build with the GitHub workflow.
