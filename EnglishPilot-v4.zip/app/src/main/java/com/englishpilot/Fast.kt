package com.englishpilot

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Fast {
    // Instant on-device rules. No network.
    fun local(t: String): List<Chg> {
        val out = ArrayList<Chg>()
        for (m in Regex(" {2,}").findAll(t))
            out.add(Chg(m.value, " ", "Spacing", "Use a single space.", "Correctness", m.range.first))
        for (m in Regex("(?<![A-Za-z0-9'’])i(?![A-Za-z0-9'’])").findAll(t))
            out.add(Chg("i", "I", "Capitalization", "Always write I with a capital letter.", "Correctness", m.range.first))
        for (m in Regex("(?:^|[.!?]\\s+)([a-z])").findAll(t)) {
            val g = m.groups[1] ?: continue
            out.add(Chg(g.value, g.value.uppercase(), "Capitalization", "Start a sentence with a capital letter.", "Correctness", g.range.first))
        }
        for (m in Regex("[,;!?](?=[A-Za-z])").findAll(t))
            out.add(Chg(m.value, m.value + " ", "Spacing", "Add a space after punctuation.", "Correctness", m.range.first))
        for (m in Regex("\\b([A-Za-z]+)\\s+\\1\\b", RegexOption.IGNORE_CASE).findAll(t))
            out.add(Chg(m.value, m.groupValues[1], "Repeated word", "This word is repeated.", "Clarity", m.range.first))
        return out
    }

    // Free LanguageTool engine (open source). Needs internet, no key.
    fun lt(st: Store, t: String): List<Chg> {
        val c = URL(st.ltUrl).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 6000
        c.readTimeout = 9000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        c.setRequestProperty("Accept", "application/json")
        val data = "language=" + st.variant + "&text=" + URLEncoder.encode(t, "UTF-8")
        c.outputStream.use { it.write(data.toByteArray()) }
        val code = c.responseCode
        if (code == 429) throw Exception("The free checker is busy. Try again in a moment.")
        if (code !in 200..299) throw Exception("Free checker error $code.")
        val j = JSONObject(c.inputStream.bufferedReader().readText())
        val ms = j.getJSONArray("matches")
        val out = ArrayList<Chg>()
        for (i in 0 until ms.length()) {
            val m = ms.getJSONObject(i)
            val reps = m.optJSONArray("replacements")
            if (reps == null || reps.length() == 0) continue
            val off = m.getInt("offset")
            val len = m.getInt("length")
            if (off < 0 || off + len > t.length) continue
            val rule = m.optJSONObject("rule")
            val cat = rule?.optJSONObject("category")?.optString("name") ?: "Grammar"
            val iss = rule?.optString("issueType") ?: ""
            val type = when (iss) { "style" -> "Clarity"; "register" -> "Delivery"; else -> "Correctness" }
            out.add(Chg(t.substring(off, off + len), reps.getJSONObject(0).getString("value"), cat, m.optString("message"), type, off))
        }
        return out
    }

    fun filter(st: Store, l: List<Chg>): List<Chg> {
        val ig = st.ignored()
        val d = st.dict()
        return l.filter { !ig.contains(it.wrong + "\u0001" + it.right) && !d.contains(it.wrong.lowercase()) }
    }

    fun build(t: String, ch: List<Chg>): Fix {
        val ok = ArrayList<Chg>()
        var end = -1
        for (c in ch.sortedBy { it.off }) {
            if (c.off >= end) { ok.add(c); end = c.off + c.wrong.length }
        }
        val sb = StringBuilder(t)
        for (c in ok.reversed()) sb.replace(c.off, c.off + c.wrong.length, c.right)
        val w = maxOf(5, t.trim().split(Regex("\\s+")).size)
        return Fix(sb.toString(), ok, "", maxOf(0, 100 - ok.size * 100 / w), "")
    }

    fun check(st: Store, t: String, useNet: Boolean, record: Boolean): Fix {
        val loc = local(t)
        val net: List<Chg> = if (useNet) lt(st, t) else emptyList()
        val all = ArrayList<Chg>(net)
        for (l in loc) {
            if (net.none { it.off < l.off + l.wrong.length && l.off < it.off + it.wrong.length }) all.add(l)
        }
        val f = build(t, filter(st, all))
        if (record) st.addHist(t.trim().split(Regex("\\s+")).size, f.changes.map { it.cat })
        return f
    }
}
