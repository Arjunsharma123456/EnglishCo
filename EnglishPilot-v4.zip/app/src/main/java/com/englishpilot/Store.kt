package com.englishpilot

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

class Store(c: Context) {
    private val p: SharedPreferences = c.getSharedPreferences("ep", Context.MODE_PRIVATE)
    private val sec: SharedPreferences = try {
        EncryptedSharedPreferences.create(
            c, "ep_secure",
            MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        c.getSharedPreferences("ep_secure_plain", Context.MODE_PRIVATE)
    }

    var key: String
        get() = sec.getString("key", "") ?: ""
        set(v) { sec.edit().putString("key", v).apply() }
    var base: String
        get() = p.getString("base", "https://api.groq.com/openai/v1") ?: ""
        set(v) { p.edit().putString("base", v).apply() }
    var model: String
        get() = p.getString("model", "openai/gpt-oss-120b") ?: ""
        set(v) { p.edit().putString("model", v).apply() }
    var lang: String
        get() = p.getString("lang", "Simple English") ?: "Simple English"
        set(v) { p.edit().putString("lang", v).apply() }
    var auto: Boolean
        get() = p.getBoolean("auto", true)
        set(v) { p.edit().putBoolean("auto", v).apply() }
    var ltUrl: String
        get() = p.getString("lt", "https://api.languagetool.org/v2/check") ?: ""
        set(v) { p.edit().putString("lt", v).apply() }
    var net: Boolean
        get() = p.getBoolean("net", true)
        set(v) { p.edit().putBoolean("net", v).apply() }
    var variant: String
        get() = p.getString("var", "en-US") ?: "en-US"
        set(v) { p.edit().putString("var", v).apply() }
    var goal: String
        get() = p.getString("goal", "Neutral") ?: "Neutral"
        set(v) { p.edit().putString("goal", v).apply() }
    fun ignored(): MutableSet<String> = HashSet(p.getStringSet("ign", emptySet()) ?: emptySet())
    fun addIgnored(k: String) {
        val s = ignored()
        s.add(k)
        p.edit().putStringSet("ign", s).apply()
    }
    fun dict(): MutableSet<String> = HashSet(p.getStringSet("dict", emptySet()) ?: emptySet())
    fun addWord(w: String) {
        val s = dict()
        s.add(w)
        p.edit().putStringSet("dict", s).apply()
    }
    var hist: JSONArray
        get() = try { JSONArray(p.getString("h", "[]")) } catch (e: Exception) { JSONArray() }
        set(v) { p.edit().putString("h", v.toString()).apply() }

    fun addHist(words: Int, cats: List<String>) {
        val old = hist
        val out = JSONArray()
        val start = maxOf(0, old.length() - 299)
        for (i in start until old.length()) out.put(old.get(i))
        out.put(JSONObject().put("t", System.currentTimeMillis()).put("w", words).put("n", cats.size).put("c", JSONArray(cats)))
        hist = out
    }
}
