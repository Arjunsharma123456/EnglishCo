package com.englishpilot

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Chg(val wrong: String, val right: String, val cat: String, val why: String)
data class Fix(val corrected: String, val changes: List<Chg>, val tip: String)

fun errText(e: Throwable?): String = when (e) {
    null -> "Something went wrong."
    is java.net.UnknownHostException, is java.net.ConnectException, is java.net.SocketTimeoutException ->
        "Cannot reach the service. Check your internet or the address in Setup."
    else -> e.message ?: "Something went wrong."
}

object Api {
    fun ask(s: Store, system: String, user: String): JSONObject {
        if (s.base.contains("groq.com") && s.key.isBlank()) throw Exception("Add your Groq key in Setup first.")
        val body = JSONObject()
            .put("model", s.model)
            .put("temperature", 0.2)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", user)))
            .put("response_format", JSONObject().put("type", "json_object"))
        var r = post(s, body)
        if (r.first == 400) {
            body.remove("response_format")
            r = post(s, body)
        }
        val code = r.first
        if (code == 401) throw Exception("The key was rejected. Check it in Setup.")
        if (code == 429) throw Exception("Free limit reached for now. Wait a minute and try again.")
        if (code !in 200..299) throw Exception("Service error $code.")
        val content = JSONObject(r.second).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
        val a = content.indexOf('{')
        val z = content.lastIndexOf('}')
        try {
            return JSONObject(content.substring(a, z + 1))
        } catch (e: Exception) {
            throw Exception("The model did not return a usable answer. Try again or pick a stronger model.")
        }
    }

    private fun post(s: Store, body: JSONObject): Pair<Int, String> {
        val c = URL(s.base.trimEnd('/') + "/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        if (s.key.isNotBlank()) c.setRequestProperty("Authorization", "Bearer " + s.key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.readText() ?: ""
        return Pair(code, text)
    }
}

object Coach {
    const val CATS = "Articles, Prepositions, Verb tense, Verb form, Agreement, Spelling, Punctuation, Capitalization, Word choice, Word order, Missing word, Spacing, Sentence structure"

    fun fix(st: Store, text: String): Fix {
        val sys = "You are a kind, precise English writing coach for a learner. Fix the user's text: grammar, spelling, " +
            "punctuation, spacing, natural wording and paragraph breaks. Keep the meaning, facts and casual or formal tone; " +
            "never invent details. Explain each change in one short sentence in this language: ${st.lang}. " +
            "Return JSON only: {\"corrected\":string,\"changes\":[{\"wrong\":string,\"right\":string," +
            "\"category\":one of [$CATS],\"why\":string}],\"tip\":\"one short rule to remember\"}. " +
            "If the text is already correct, return it unchanged with an empty changes list."
        val j = Api.ask(st, sys, text)
        val arr = j.optJSONArray("changes") ?: JSONArray()
        val ch = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Chg(o.optString("wrong"), o.optString("right"), o.optString("category"), o.optString("why"))
        }
        st.addHist(text.trim().split(Regex("\\s+")).size, ch.map { it.cat })
        return Fix(j.optString("corrected", text), ch, j.optString("tip"))
    }

    fun practice(st: Store): List<Triple<String, String, String>> {
        val cnt = HashMap<String, Int>()
        val h = st.hist
        for (i in 0 until h.length()) {
            val c = h.getJSONObject(i).getJSONArray("c")
            for (k in 0 until c.length()) cnt[c.getString(k)] = (cnt[c.getString(k)] ?: 0) + 1
        }
        val top = cnt.entries.sortedByDescending { it.value }.take(3).map { it.key }
        val focus = if (top.isEmpty()) "Articles, Prepositions, Verb form" else top.joinToString(", ")
        val j = Api.ask(st,
            "You write short English practice for a learner. Return JSON only: " +
                "{\"items\":[{\"wrong\":string,\"answer\":string,\"rule\":string}]}. " +
                "Make 5 everyday sentences, each with exactly one mistake, from these areas: $focus. " +
                "\"rule\" is one short sentence in ${st.lang}.",
            "Make my practice.")
        val arr = j.optJSONArray("items") ?: JSONArray()
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Triple(o.optString("wrong"), o.optString("answer"), o.optString("rule"))
        }
    }
}
